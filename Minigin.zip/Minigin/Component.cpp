#include "MiniginPCH.h"
#include "Component.h"

void dae::Component::Update(float deltaTime)
{
	++deltaTime; // "unreferenced formal parameter" error
}